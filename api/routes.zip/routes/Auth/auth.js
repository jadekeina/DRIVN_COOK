const express = require('express');
const router = express.Router();
const AuthController = require('../../controllers/authController');
const { authenticateToken } = require('../../middleware/auth');
const validators = require('../../middleware/validators');

// Routes publiques
router.post('/register', validators.register, AuthController.register);
router.post('/login', validators.login, AuthController.login);

// Routes protégées
router.get('/profile', authenticateToken, AuthController.getProfile);
router.put('/profile', authenticateToken, validators.updateProfile, AuthController.updateProfile);

module.exports = router;