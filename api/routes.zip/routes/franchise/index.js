const express = require('express');
const router = express.Router();

console.log('📁 Chargement du contrôleur franchise...');

// Chargement sécurisé du contrôleur
let controller;
try {
    controller = require('../../controllers/franchise/franchiseController');
    console.log('- Contrôleur franchise chargé');
} catch (error) {
    console.error('-- Erreur chargement contrôleur:', error.message);

    // Contrôleur de fallback
    controller = {
        getAll: (req, res) => {
            res.json({
                success: true,
                message: 'Contrôleur de fallback - getAll',
                data: []
            });
        },
        create: (req, res) => {
            res.json({
                success: true,
                message: 'Contrôleur de fallback - create',
                data: req.body
            });
        }
    };
}

console.log('🛣️  Définition des routes...');

// Routes de base - PAS DE PARAMÈTRES POUR L'INSTANT
router.get('/', (req, res) => {
    console.log('GET / appelé');
    controller.getAll(req, res);
});

router.post('/', (req, res) => {
    console.log('POST / appelé');
    controller.create(req, res);
});

// IMPORTANT: On évite les routes avec paramètres pour l'instant
// router.get('/:id', ...) PEUT CAUSER L'ERREUR path-to-regexp

console.log('🧪 Toutes les routes définies :');
console.log(router.stack.map(r => r.route?.path || 'MIDDLEWARE'));


console.log('-Routes franchise définies');

console.log('🧪 Stack du router complet :');
router.stack.forEach((layer, i) => {
    const route = layer.route;
    if (route) {
        console.log(`${i}: ${route.path} → ${Object.keys(route.methods).join(', ').toUpperCase()}`);
    }
});


module.exports = router;